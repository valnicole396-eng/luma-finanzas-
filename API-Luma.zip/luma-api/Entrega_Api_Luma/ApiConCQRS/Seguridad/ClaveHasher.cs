﻿using System.Security.Cryptography;

namespace ApiConCQRS.Seguridad
{
    /// <summary>Guarda las contraseñas como hash PBKDF2 (nunca en texto plano).</summary>
    public static class ClaveHasher
    {
        private const int Iteraciones = 100_000;
        private const int TamanoSal = 16;
        private const int TamanoHash = 32;

        public static string Hashear(string clave)
        {
            var sal = RandomNumberGenerator.GetBytes(TamanoSal);
            var hash = Rfc2898DeriveBytes.Pbkdf2(clave, sal, Iteraciones, HashAlgorithmName.SHA256, TamanoHash);
            return $"{Iteraciones}.{Convert.ToBase64String(sal)}.{Convert.ToBase64String(hash)}";
        }

        public static bool Verificar(string clave, string guardada)
        {
            try
            {
                var partes = guardada.Split('.');
                if (partes.Length != 3 || !int.TryParse(partes[0], out var iteraciones)) return false;

                var sal = Convert.FromBase64String(partes[1]);
                var esperado = Convert.FromBase64String(partes[2]);
                var hash = Rfc2898DeriveBytes.Pbkdf2(clave, sal, iteraciones, HashAlgorithmName.SHA256, esperado.Length);
                return CryptographicOperations.FixedTimeEquals(hash, esperado);
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
