﻿using ApiConCQRS.Dtos;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository.Interfaces;
using ApiConCQRS.Seguridad;
using Microsoft.AspNetCore.Mvc;

namespace ApiConCQRS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioQuery _query;
        private readonly IUsuarioRepository _repository;

        public UsuarioController(IUsuarioQuery query, IUsuarioRepository repository)
        {
            _query = query;
            _repository = repository;
        }

        private static string Normalizar(string correo)
            => (correo ?? string.Empty).Trim().ToLowerInvariant();

        private static UsuarioRespuesta Responder(Usuario u) => new()
        {
            id_usuario = u.id_usuario,
            nombre = u.nombre,
            correo = u.correo
        };

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UsuarioRespuesta>>> ObtenerTodos()
            => Ok((await _query.ObtenerTodosAsync()).Select(Responder));

        [HttpGet("{id}")]
        public async Task<ActionResult<UsuarioRespuesta>> ObtenerPorId(int id)
        {
            var resultado = await _query.ObtenerPorIdAsync(id);
            return resultado is null ? NotFound() : Ok(Responder(resultado));
        }

        [HttpPost]
        public async Task<ActionResult> Crear([FromBody] Usuario entidad)
        {
            entidad.nombre = (entidad.nombre ?? string.Empty).Trim();
            entidad.correo = Normalizar(entidad.correo);

            if (entidad.nombre.Length == 0 || !entidad.correo.Contains('@'))
                return BadRequest(new { mensaje = "Nombre y correo válido son obligatorios" });
            if ((entidad.contrasena ?? string.Empty).Length < 4)
                return BadRequest(new { mensaje = "La contraseña debe tener mínimo 4 caracteres" });
            if (await _query.ObtenerPorCorreoAsync(entidad.correo) is not null)
                return Conflict(new { mensaje = "Ese correo ya tiene una cuenta" });

            entidad.contrasena = ClaveHasher.Hashear(entidad.contrasena!);
            entidad.id_usuario = await _repository.CrearAsync(entidad);
            return CreatedAtAction(nameof(ObtenerPorId), new { id = entidad.id_usuario }, Responder(entidad));
        }

        [HttpPost("login")]
        public async Task<ActionResult<UsuarioRespuesta>> Login([FromBody] LoginSolicitud solicitud)
        {
            var usuario = await _query.ObtenerPorCorreoAsync(Normalizar(solicitud.correo));
            if (usuario is null || !ClaveHasher.Verificar(solicitud.contrasena, usuario.contrasena))
                return Unauthorized(new { mensaje = "Correo o contraseña incorrectos" });

            return Ok(Responder(usuario));
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Actualizar(int id, [FromBody] Usuario entidad)
        {
            var actual = await _query.ObtenerPorIdAsync(id);
            if (actual is null) return NotFound();

            entidad.id_usuario = id;
            entidad.correo = Normalizar(entidad.correo);
            entidad.contrasena = string.IsNullOrEmpty(entidad.contrasena)
                ? actual.contrasena
                : ClaveHasher.Hashear(entidad.contrasena);

            return await _repository.ActualizarAsync(entidad) ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Eliminar(int id)
            => await _repository.EliminarAsync(id) ? NoContent() : NotFound();
    }
}
