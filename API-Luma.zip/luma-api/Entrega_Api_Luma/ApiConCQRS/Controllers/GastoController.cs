﻿using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ApiConCQRS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GastoController : ControllerBase
    {
        private readonly IGastoQuery _query;
        private readonly IGastoRepository _repository;

        public GastoController(IGastoQuery query, IGastoRepository repository)
        {
            _query = query;
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Gasto>>> ObtenerTodos([FromQuery] int? idUsuario)
            => Ok(idUsuario is null
                ? await _query.ObtenerTodosAsync()
                : await _query.ObtenerPorUsuarioAsync(idUsuario.Value));

        [HttpGet("{id}")]
        public async Task<ActionResult<Gasto>> ObtenerPorId(int id)
        {
            var resultado = await _query.ObtenerPorIdAsync(id);
            return resultado is null ? NotFound() : Ok(resultado);
        }

        [HttpPost]
        public async Task<ActionResult> Crear([FromBody] Gasto entidad)
        {
            var id = await _repository.CrearAsync(entidad);
            entidad.id_gasto = id;
            return CreatedAtAction(nameof(ObtenerPorId), new { id }, entidad);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Actualizar(int id, [FromBody] Gasto entidad)
        {
            entidad.id_gasto = id;
            return await _repository.ActualizarAsync(entidad) ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Eliminar(int id)
            => await _repository.EliminarAsync(id) ? NoContent() : NotFound();
    }
}