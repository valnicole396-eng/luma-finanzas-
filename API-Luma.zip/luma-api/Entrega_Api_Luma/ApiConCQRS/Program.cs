
using System.Data;
using System.Reflection;
using ApiConCQRS.Query;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository;
using ApiConCQRS.Repository.Interfaces;
using Microsoft.Data.SqlClient;

namespace ApiConCQRS
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllers(opt =>
                opt.SuppressImplicitRequiredAttributeForNonNullableReferenceTypes = true);
            builder.Services.AddCors(opt => opt.AddPolicy("Luma", p =>
                p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(opt =>
            {
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                if (File.Exists(xmlPath))
                    opt.IncludeXmlComments(xmlPath);
            });

            builder.Services.AddScoped<IDbConnection>(opt =>
            {
                string connectionString = builder.Configuration.GetConnectionString("sql")!;
                return new SqlConnection(connectionString);
            });

            builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
            builder.Services.AddScoped<IUsuarioQuery, UsuarioQuery>();
            builder.Services.AddScoped<ICategoriaRepository, CategoriaRepository>();
            builder.Services.AddScoped<ICategoriaQuery, CategoriaQuery>();
            builder.Services.AddScoped<IIngresoRepository, IngresoRepository>();
            builder.Services.AddScoped<IIngresoQuery, IngresoQuery>();
            builder.Services.AddScoped<IGastoRepository, GastoRepository>();
            builder.Services.AddScoped<IGastoQuery, GastoQuery>();
            builder.Services.AddScoped<IMetaRepository, MetaRepository>();
            builder.Services.AddScoped<IMetaQuery, MetaQuery>();
            builder.Services.AddScoped<IPresupuestoRepository, PresupuestoRepository>();
            builder.Services.AddScoped<IPresupuestoQuery, PresupuestoQuery>();
            var app = builder.Build();

            app.UseSwagger();
            app.UseSwaggerUI();
            app.UseCors("Luma");
            app.UseAuthorization();
            app.MapControllers();

            app.Run();
        }
    }
}