﻿namespace ApiConCQRS.Dtos
{
    /// <summary>Datos del usuario que se devuelven al cliente (sin contraseña).</summary>
    public class UsuarioRespuesta
    {
        public int id_usuario { get; set; }
        public string nombre { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
    }

    public class LoginSolicitud
    {
        public string correo { get; set; } = string.Empty;
        public string contrasena { get; set; } = string.Empty;
    }
}
