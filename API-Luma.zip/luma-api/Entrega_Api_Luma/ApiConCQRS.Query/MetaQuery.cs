﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class MetaQuery : IMetaQuery
    {
        private readonly IDbConnection _connection;

        public MetaQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Meta?> ObtenerPorIdAsync(int id_meta)
        {
            return await _connection.GetAsync<Meta>(id_meta);
        }

        public async Task<IEnumerable<Meta>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Meta>();
        }

        public async Task<IEnumerable<Meta>> ObtenerPorUsuarioAsync(int id_usuario)
        {
            const string sql = "SELECT * FROM Meta WHERE id_usuario = @id_usuario;";
            return await _connection.QueryAsync<Meta>(sql, new { id_usuario });
        }
    }
}