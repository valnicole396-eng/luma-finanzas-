﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class CategoriaQuery : ICategoriaQuery
    {
        private readonly IDbConnection _connection;

        public CategoriaQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Categoria?> ObtenerPorIdAsync(int id_categoria)
        {
            return await _connection.GetAsync<Categoria>(id_categoria);
        }

        public async Task<IEnumerable<Categoria>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Categoria>();
        }
    }
}