﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class UsuarioQuery : IUsuarioQuery
    {
        private readonly IDbConnection _connection;

        public UsuarioQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Usuario?> ObtenerPorIdAsync(int id_usuario)
        {
            return await _connection.GetAsync<Usuario>(id_usuario);
        }

        public async Task<IEnumerable<Usuario>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Usuario>();
        }

        public async Task<Usuario?> ObtenerPorCorreoAsync(string correo)
        {
            const string sql = "SELECT TOP 1 * FROM Usuario WHERE correo = @correo;";
            return await _connection.QueryFirstOrDefaultAsync<Usuario>(sql, new { correo });
        }
    }
}