﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class PresupuestoQuery : IPresupuestoQuery
    {
        private readonly IDbConnection _connection;

        public PresupuestoQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Presupuesto?> ObtenerPorIdAsync(int id_presupuesto)
        {
            return await _connection.GetAsync<Presupuesto>(id_presupuesto);
        }

        public async Task<IEnumerable<Presupuesto>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Presupuesto>();
        }

        public async Task<IEnumerable<Presupuesto>> ObtenerPorUsuarioAsync(int id_usuario)
        {
            const string sql = "SELECT * FROM Presupuesto WHERE id_usuario = @id_usuario;";
            return await _connection.QueryAsync<Presupuesto>(sql, new { id_usuario });
        }
    }
}