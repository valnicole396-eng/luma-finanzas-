﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface IIngresoQuery
    {
        Task<Ingreso?> ObtenerPorIdAsync(int id_ingreso);
        Task<IEnumerable<Ingreso>> ObtenerTodosAsync();
        Task<IEnumerable<Ingreso>> ObtenerPorUsuarioAsync(int id_usuario);
    }
}