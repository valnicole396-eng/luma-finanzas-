﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface IGastoQuery
    {
        Task<Gasto?> ObtenerPorIdAsync(int id_gasto);
        Task<IEnumerable<Gasto>> ObtenerTodosAsync();
        Task<IEnumerable<Gasto>> ObtenerPorUsuarioAsync(int id_usuario);
    }
}
