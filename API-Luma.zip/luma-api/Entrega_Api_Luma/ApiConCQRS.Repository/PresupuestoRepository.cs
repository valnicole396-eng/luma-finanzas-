﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class PresupuestoRepository : IPresupuestoRepository
    {
        private readonly IDbConnection _connection;

        public PresupuestoRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Presupuesto entidad)
        {
            const string sql = @"INSERT INTO Presupuesto (id_usuario, monto_limite, periodo, fecha_inicio, fecha_fin)
                                  VALUES (@id_usuario, @monto_limite, @periodo, @fecha_inicio, @fecha_fin);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Presupuesto entidad)
        {
            const string sql = @"UPDATE Presupuesto
                                  SET id_usuario = @id_usuario, monto_limite = @monto_limite,
                                      periodo = @periodo, fecha_inicio = @fecha_inicio, fecha_fin = @fecha_fin
                                  WHERE id_presupuesto = @id_presupuesto;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_presupuesto)
        {
            const string sql = "DELETE FROM Presupuesto WHERE id_presupuesto = @id_presupuesto;";
            var filas = await _connection.ExecuteAsync(sql, new { id_presupuesto });
            return filas > 0;
        }
    }
}