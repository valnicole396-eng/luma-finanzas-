﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private readonly IDbConnection _connection;

        public UsuarioRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Usuario entidad)
        {
            const string sql = @"INSERT INTO Usuario (nombre, correo, contrasena)
                                  VALUES (@nombre, @correo, @contrasena);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Usuario entidad)
        {
            const string sql = @"UPDATE Usuario
                                  SET nombre = @nombre, correo = @correo, contrasena = @contrasena
                                  WHERE id_usuario = @id_usuario;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_usuario)
        {
            const string sql = "DELETE FROM Usuario WHERE id_usuario = @id_usuario;";
            var filas = await _connection.ExecuteAsync(sql, new { id_usuario });
            return filas > 0;
        }
    }
}