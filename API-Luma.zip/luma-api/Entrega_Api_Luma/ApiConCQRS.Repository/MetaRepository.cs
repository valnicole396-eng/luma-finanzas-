﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class MetaRepository : IMetaRepository
    {
        private readonly IDbConnection _connection;

        public MetaRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Meta entidad)
        {
            const string sql = @"INSERT INTO Meta (id_usuario, nombre, monto_objetivo, monto_actual, fecha_limite, estado)
                                  VALUES (@id_usuario, @nombre, @monto_objetivo, @monto_actual, @fecha_limite, @estado);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Meta entidad)
        {
            const string sql = @"UPDATE Meta
                                  SET id_usuario = @id_usuario, nombre = @nombre,
                                      monto_objetivo = @monto_objetivo, monto_actual = @monto_actual,
                                      fecha_limite = @fecha_limite, estado = @estado
                                  WHERE id_meta = @id_meta;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_meta)
        {
            const string sql = "DELETE FROM Meta WHERE id_meta = @id_meta;";
            var filas = await _connection.ExecuteAsync(sql, new { id_meta });
            return filas > 0;
        }
    }
}