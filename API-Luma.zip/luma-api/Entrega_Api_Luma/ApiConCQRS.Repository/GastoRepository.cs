﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class GastoRepository : IGastoRepository
    {
        private readonly IDbConnection _connection;

        public GastoRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Gasto entidad)
        {
            const string sql = @"INSERT INTO Gasto (id_usuario, id_categoria, monto, fecha, descripcion)
                                  VALUES (@id_usuario, @id_categoria, @monto, @fecha, @descripcion);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Gasto entidad)
        {
            const string sql = @"UPDATE Gasto
                                  SET id_usuario = @id_usuario, id_categoria = @id_categoria,
                                      monto = @monto, fecha = @fecha, descripcion = @descripcion
                                  WHERE id_gasto = @id_gasto;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_gasto)
        {
            const string sql = "DELETE FROM Gasto WHERE id_gasto = @id_gasto;";
            var filas = await _connection.ExecuteAsync(sql, new { id_gasto });
            return filas > 0;
        }
    }
}