﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface IMetaRepository
    {
        Task<int> CrearAsync(Meta entidad);
        Task<bool> ActualizarAsync(Meta entidad);
        Task<bool> EliminarAsync(int id_meta);
    }
}