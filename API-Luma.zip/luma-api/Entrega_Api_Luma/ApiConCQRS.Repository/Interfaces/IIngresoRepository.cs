﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface IIngresoRepository
    {
        Task<int> CrearAsync(Ingreso entidad);
        Task<bool> ActualizarAsync(Ingreso entidad);
        Task<bool> EliminarAsync(int id_ingreso);
    }
}