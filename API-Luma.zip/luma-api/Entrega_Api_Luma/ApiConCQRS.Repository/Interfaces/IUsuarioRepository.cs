﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface IUsuarioRepository
    {
        Task<int> CrearAsync(Usuario entidad);
        Task<bool> ActualizarAsync(Usuario entidad);
        Task<bool> EliminarAsync(int id_usuario);
    }
}
