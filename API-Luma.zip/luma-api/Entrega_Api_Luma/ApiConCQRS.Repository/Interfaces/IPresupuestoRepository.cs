﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface IPresupuestoRepository
    {
        Task<int> CrearAsync(Presupuesto entidad);
        Task<bool> ActualizarAsync(Presupuesto entidad);
        Task<bool> EliminarAsync(int id_presupuesto);
    }
}