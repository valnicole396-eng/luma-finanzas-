﻿using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Models
{
    [Table("Usuario")]
    public class Usuario
    {
        [Key]
        public int id_usuario { get; set; }

        public string nombre { get; set; } = string.Empty;
        public string correo { get; set; } = string.Empty;
        public string contrasena { get; set; } = string.Empty;
    }
}