﻿using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Models
{
    [Table("Categoria")]
    public class Categoria
    {
        [Key]
        public int id_categoria { get; set; }

        public string nombre { get; set; } = string.Empty;
        public string tipo { get; set; } = string.Empty;
    }
}