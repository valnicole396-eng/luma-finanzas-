# Cambios a la API de Luma

## Qué se cambió
1. **Login**: nuevo `POST /api/Usuario/login` (body: `correo`, `contrasena`). Devuelve el usuario sin contraseña o 401.
2. **Contraseñas con hash** (PBKDF2, `Seguridad/ClaveHasher.cs`). Ya no se guardan ni se devuelven en texto plano. `GET /api/Usuario` devuelve solo `id_usuario`, `nombre` y `correo`.
3. **Registro validado**: `POST /api/Usuario` revisa nombre, correo y contraseña (mínimo 4) y responde 409 si el correo ya existe.
4. **Filtro por usuario**: `GET /api/Gasto?idUsuario=1` (igual para Ingreso, Meta y Presupuesto). Se agregó `ObtenerPorUsuarioAsync` en la capa Query. Sin el parámetro devuelve todo, como antes.
5. **CORS** habilitado (política "Luma").
6. **launchSettings**: la API escucha en `http://0.0.0.0:5047` para que el celular pueda conectarse por la red.
7. Los `POST` ahora devuelven el objeto creado **con su id** (antes llegaba 0) y se aceptan textos vacíos como la descripción.
8. **DDL**: al final de `Luma_DDL.sql` se cargan las categorías iniciales (5 de gasto y 3 de ingreso).

## Cómo probarla (en el PC con Windows y SQL Server Express)
1. Ejecutar `Luma_DDL.sql` en SQL Server Management Studio. Si la base ya existe, ejecutar solo el bloque final de categorías.
2. En la carpeta `ApiConCQRS`: `dotnet run --launch-profile http`
3. Abrir `http://localhost:5047/swagger` y probar: crear usuario, hacer login, crear un gasto con `id_usuario` e `id_categoria`, y listarlo con `?idUsuario=`.

## Para conectar el celular
1. En PowerShell como administrador: `New-NetFirewallRule -DisplayName "Luma API" -Direction Inbound -LocalPort 5047 -Protocol TCP -Action Allow`
2. Ver la IP del PC con `ipconfig` (IPv4). El celular y el PC deben estar en la misma red Wi-Fi.
3. En la app: `EXPO_PUBLIC_API_URL=http://IP-DEL-PC:5047`

## Pendiente
- Los usuarios creados antes con contraseña en texto plano no podrán iniciar sesión: hay que registrarlos de nuevo.
- Volver a exportar `swagger.json` desde `/swagger/v1/swagger.json` cuando la API corra, porque el actual no incluye el login ni el filtro.
- Estos cambios no se compilaron todavía: si Visual Studio marca algún error, hay que enviarlo para corregirlo.
