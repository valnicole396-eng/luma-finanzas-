export const colors = {
  primary: '#73395A',
  medium: '#9C6B88',
  light: '#D3A9C2',
  bg: '#FCF1F5',
  card: '#FFFFFF',
  text: '#4A2A3E',
  muted: '#9C7A8E',
  green: '#2E8B57',
};
