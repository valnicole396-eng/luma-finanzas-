import { ReactNode } from 'react';
import { View, useWindowDimensions } from 'react-native';

export default function Columnas({ izquierda, derecha }: { izquierda: ReactNode; derecha: ReactNode }) {
  const { width } = useWindowDimensions();

  if (width < 900) {
    return (
      <View>
        {izquierda}
        {derecha}
      </View>
    );
  }

  return (
    <View style={{ flexDirection: 'row', gap: 28, alignItems: 'flex-start' }}>
      <View style={{ flex: 1 }}>{izquierda}</View>
      <View style={{ flex: 1 }}>{derecha}</View>
    </View>
  );
}
