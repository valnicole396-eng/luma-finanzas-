import { View, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../theme/colors';

export default function Placeholder({ titulo }: { titulo: string }) {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <View style={{ padding: 20 }}>
        <Text style={{ fontSize: 22, fontWeight: '700', color: colors.primary }}>{titulo}</Text>
        <Text style={{ color: colors.muted, marginTop: 8 }}>Próximamente</Text>
      </View>
    </SafeAreaView>
  );
}
