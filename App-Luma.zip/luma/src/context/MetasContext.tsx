import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { usePersistentState } from '../hooks/usePersistentState';
import { API_ACTIVA, api, MetaApi } from '../services/api';
import { useSesionId } from '../services/sesion';

export type Abono = { id: number; monto: number; fecha: string };
export type Meta = {
  id: number;
  nombre: string;
  montoObjetivo: number;
  fechaLimite: string;
  abonos: Abono[];
};

const iniciales: Meta[] = [
  { id: 1, nombre: 'Viaje', montoObjetivo: 1500000, fechaLimite: '2026-12-20', abonos: [{ id: 11, monto: 400000, fecha: '2026-09-15' }] },
  { id: 2, nombre: 'Computador nuevo', montoObjetivo: 3000000, fechaLimite: '2027-03-01', abonos: [{ id: 12, monto: 600000, fecha: '2026-09-30' }] },
];

type Ctx = {
  metas: Meta[];
  agregarMeta: (m: Omit<Meta, 'id' | 'abonos'>) => void;
  abonar: (idMeta: number, monto: number) => void;
  eliminarMeta: (id: number) => void;
};

const MetasContext = createContext<Ctx>({} as Ctx);

const hoy = () => new Date().toLocaleDateString('en-CA');
const total = (m: Meta) => m.abonos.reduce((a, ab) => a + ab.monto, 0);

// La API guarda solo el monto ahorrado (monto_actual), no cada abono por separado.
// En modo API la app muestra ese total como un único abono.
const aMeta = (m: MetaApi): Meta => ({
  id: m.id_meta,
  nombre: m.nombre,
  montoObjetivo: Number(m.monto_objetivo),
  fechaLimite: m.fecha_limite ? String(m.fecha_limite).slice(0, 10) : '',
  abonos: Number(m.monto_actual) > 0 ? [{ id: m.id_meta, monto: Number(m.monto_actual), fecha: hoy() }] : [],
});

export function MetasProvider({ children }: { children: ReactNode }) {
  const [locales, setLocales] = usePersistentState<Meta[]>('luma:metas', iniciales);
  const [remotas, setRemotas] = useState<Meta[]>([]);
  const idUsuario = useSesionId();

  const metas = API_ACTIVA ? remotas : locales;

  const recargar = async () => {
    if (!API_ACTIVA || idUsuario === null) {
      setRemotas([]);
      return;
    }
    try {
      const lista = await api.listar<MetaApi>('Meta', idUsuario);
      setRemotas(lista.map(aMeta));
    } catch {}
  };

  useEffect(() => {
    recargar();
  }, [idUsuario]);

  const cuerpo = (m: Pick<Meta, 'nombre' | 'montoObjetivo' | 'fechaLimite'>, ahorrado: number) => ({
    id_usuario: idUsuario,
    nombre: m.nombre,
    monto_objetivo: m.montoObjetivo,
    monto_actual: ahorrado,
    fecha_limite: `${m.fechaLimite || hoy()}T00:00:00`,
    estado: ahorrado >= m.montoObjetivo ? 'completada' : 'activa',
  });

  const agregarMeta = (m: Omit<Meta, 'id' | 'abonos'>) => {
    if (!API_ACTIVA) {
      setLocales((prev) => [...prev, { ...m, id: Date.now(), abonos: [] }]);
      return;
    }
    if (idUsuario === null) return;
    api.crear('Meta', cuerpo(m, 0)).then(recargar).catch(() => {});
  };

  const abonar = (idMeta: number, monto: number) => {
    if (!API_ACTIVA) {
      setLocales((prev) =>
        prev.map((m) =>
          m.id === idMeta
            ? { ...m, abonos: [...m.abonos, { id: Date.now(), monto, fecha: hoy() }] }
            : m
        )
      );
      return;
    }
    const meta = remotas.find((m) => m.id === idMeta);
    if (!meta || idUsuario === null) return;
    api.editar('Meta', idMeta, cuerpo(meta, total(meta) + monto)).then(recargar).catch(() => {});
  };

  const eliminarMeta = (id: number) => {
    if (!API_ACTIVA) {
      setLocales((prev) => prev.filter((m) => m.id !== id));
      return;
    }
    api.borrar('Meta', id).then(recargar).catch(() => {});
  };

  return (
    <MetasContext.Provider value={{ metas, agregarMeta, abonar, eliminarMeta }}>
      {children}
    </MetasContext.Provider>
  );
}

export const useMetas = () => useContext(MetasContext);
