import { createContext, useContext, useEffect, ReactNode } from 'react';
import { usePersistentState } from '../hooks/usePersistentState';
import { API_ACTIVA, api, mensajeError } from '../services/api';
import { fijarSesion } from '../services/sesion';

export type Usuario = { nombre: string; correo: string; foto?: string; desde: string };
type Cuenta = Usuario & { clave: string };
type SesionApi = { id_usuario: number; nombre: string; correo: string; desde: string };

const hoy = () => new Date().toLocaleDateString('en-CA');

const cuentaDemo: Cuenta = {
  nombre: 'Usuario Luma',
  correo: 'demo@luma.com',
  clave: '1234',
  desde: hoy(),
};

type Ctx = {
  usuario: Usuario | null;
  listo: boolean;
  registrar: (nombre: string, correo: string, clave: string) => Promise<string | null>;
  ingresar: (correo: string, clave: string) => Promise<string | null>;
  salir: () => void;
  actualizar: (cambios: { nombre?: string; foto?: string }) => void;
};

const AuthContext = createContext<Ctx>({} as Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  // Modo local (sin API)
  const [cuentas, setCuentas, cuentasListo] = usePersistentState<Cuenta[]>('luma:cuentas', [cuentaDemo]);
  const [sesion, setSesion, sesionListo] = usePersistentState<string | null>('luma:sesion', null);
  // Modo API
  const [sesionApi, setSesionApi, apiListo] = usePersistentState<SesionApi | null>('luma:sesion-api', null);
  const [fotos, setFotos, fotosListo] = usePersistentState<Record<string, string>>('luma:fotos', {});

  useEffect(() => {
    fijarSesion(API_ACTIVA && sesionApi ? sesionApi.id_usuario : null);
  }, [sesionApi]);

  const limpiar = (c: string) => c.trim().toLowerCase();

  const entrarConApi = (u: { id_usuario: number; nombre: string; correo: string }) =>
    setSesionApi({ id_usuario: u.id_usuario, nombre: u.nombre, correo: u.correo, desde: hoy() });

  const registrar = async (nombre: string, correo: string, clave: string) => {
    const mail = limpiar(correo);
    if (API_ACTIVA) {
      try {
        entrarConApi(await api.registrar(nombre.trim(), mail, clave));
        return null;
      } catch (e) {
        return mensajeError(e);
      }
    }
    if (cuentas.some((c) => c.correo === mail)) return 'Ese correo ya tiene una cuenta';
    setCuentas((prev) => [...prev, { nombre: nombre.trim(), correo: mail, clave, desde: hoy() }]);
    setSesion(mail);
    return null;
  };

  const ingresar = async (correo: string, clave: string) => {
    const mail = limpiar(correo);
    if (API_ACTIVA) {
      try {
        entrarConApi(await api.login(mail, clave));
        return null;
      } catch (e) {
        return mensajeError(e);
      }
    }
    const ok = cuentas.some((c) => c.correo === mail && c.clave === clave);
    if (!ok) return 'Correo o contraseña incorrectos';
    setSesion(mail);
    return null;
  };

  const salir = () => {
    setSesion(null);
    setSesionApi(null);
  };

  const actualizar = (cambios: { nombre?: string; foto?: string }) => {
    if (API_ACTIVA) {
      if (!sesionApi) return;
      const { correo, id_usuario } = sesionApi;
      if (cambios.foto) {
        const foto = cambios.foto;
        setFotos((prev) => ({ ...prev, [correo]: foto }));
      }
      if (cambios.nombre) {
        const nombre = cambios.nombre;
        setSesionApi({ ...sesionApi, nombre });
        // contrasena vacía = la API conserva la actual
        api.editar('Usuario', id_usuario, { id_usuario, nombre, correo, contrasena: '' }).catch(() => {});
      }
      return;
    }
    setCuentas((prev) => prev.map((c) => (c.correo === sesion ? { ...c, ...cambios } : c)));
  };

  const cuenta = cuentas.find((c) => c.correo === sesion);
  const usuario: Usuario | null = API_ACTIVA
    ? sesionApi
      ? { nombre: sesionApi.nombre, correo: sesionApi.correo, foto: fotos[sesionApi.correo], desde: sesionApi.desde }
      : null
    : cuenta
      ? { nombre: cuenta.nombre, correo: cuenta.correo, foto: cuenta.foto, desde: cuenta.desde }
      : null;

  return (
    <AuthContext.Provider
      value={{
        usuario,
        listo: cuentasListo && sesionListo && apiListo && fotosListo,
        registrar,
        ingresar,
        salir,
        actualizar,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
