import { createContext, useContext, useEffect, useRef, useState, ReactNode } from 'react';
import { usePersistentState } from '../hooks/usePersistentState';
import { API_ACTIVA, api, CategoriaApi, GastoApi, IngresoApi } from '../services/api';
import { useSesionId } from '../services/sesion';

type Tipo = 'ingreso' | 'gasto';

export type Movimiento = {
  id: number;
  tipo: Tipo;
  monto: number;
  categoria: string;
  descripcion: string;
  fecha: string;
};

export const categoriasGasto = ['Alimentación', 'Transporte', 'Ocio', 'Estudios', 'Otros'];
export const categoriasIngreso = ['Salario', 'Mesada', 'Otros'];

const iniciales: Movimiento[] = [
  { id: 1, tipo: 'ingreso', monto: 2100000, categoria: 'Salario', descripcion: 'Pago mensual', fecha: '2026-10-01' },
  { id: 2, tipo: 'gasto', monto: 320000, categoria: 'Alimentación', descripcion: 'Mercado', fecha: '2026-10-02' },
  { id: 3, tipo: 'gasto', monto: 180000, categoria: 'Transporte', descripcion: 'Pasajes', fecha: '2026-10-02' },
  { id: 4, tipo: 'gasto', monto: 150000, categoria: 'Ocio', descripcion: 'Salida con amigos', fecha: '2026-10-03' },
  { id: 5, tipo: 'gasto', monto: 120000, categoria: 'Estudios', descripcion: 'Libros', fecha: '2026-10-03' },
  { id: 6, tipo: 'gasto', monto: 90000, categoria: 'Otros', descripcion: 'Varios', fecha: '2026-10-04' },
];

type Ctx = {
  movimientos: Movimiento[];
  agregar: (m: Omit<Movimiento, 'id'>) => void;
  editar: (m: Movimiento) => void;
  eliminar: (id: number) => void;
};

const DataContext = createContext<Ctx>({} as Ctx);

// En la API los ingresos y los gastos son tablas distintas y sus ids pueden repetirse.
// Para que la app tenga un id único: ingreso = id*2, gasto = id*2+1.
const idApp = (tipo: Tipo, idReal: number) => idReal * 2 + (tipo === 'gasto' ? 1 : 0);
const idReal = (id: number) => Math.floor(id / 2);
const recurso = (tipo: Tipo) => (tipo === 'gasto' ? 'Gasto' : 'Ingreso');

export function DataProvider({ children }: { children: ReactNode }) {
  const [locales, setLocales] = usePersistentState<Movimiento[]>('luma:movimientos', iniciales);
  const [remotos, setRemotos] = useState<Movimiento[]>([]);
  const idUsuario = useSesionId();
  const categorias = useRef<CategoriaApi[]>([]);

  const movimientos = API_ACTIVA ? remotos : locales;

  const aMovimiento = (tipo: Tipo, r: IngresoApi | GastoApi): Movimiento => {
    const id = tipo === 'gasto' ? (r as GastoApi).id_gasto : (r as IngresoApi).id_ingreso;
    return {
      id: idApp(tipo, id),
      tipo,
      monto: Number(r.monto),
      categoria: categorias.current.find((c) => c.id_categoria === r.id_categoria)?.nombre ?? 'Otros',
      descripcion: r.descripcion ?? '',
      fecha: String(r.fecha).slice(0, 10),
    };
  };

  const recargar = async () => {
    if (!API_ACTIVA || idUsuario === null) {
      setRemotos([]);
      return;
    }
    try {
      const [cats, ingresos, gastos] = await Promise.all([
        api.listar<CategoriaApi>('Categoria'),
        api.listar<IngresoApi>('Ingreso', idUsuario),
        api.listar<GastoApi>('Gasto', idUsuario),
      ]);
      categorias.current = cats;
      setRemotos([
        ...ingresos.map((r) => aMovimiento('ingreso', r)),
        ...gastos.map((r) => aMovimiento('gasto', r)),
      ]);
    } catch {}
  };

  useEffect(() => {
    recargar();
  }, [idUsuario]);

  // Busca la categoría por nombre y tipo; si no existe en la base, la crea
  const idCategoria = async (tipo: Tipo, nombre: string) => {
    const hallada = categorias.current.find((c) => c.nombre === nombre && c.tipo === tipo);
    if (hallada) return hallada.id_categoria;
    const nueva = await api.crear<CategoriaApi>('Categoria', { nombre, tipo });
    categorias.current = [...categorias.current, nueva];
    return nueva.id_categoria;
  };

  const cuerpo = async (m: Omit<Movimiento, 'id'>) => ({
    id_usuario: idUsuario,
    id_categoria: await idCategoria(m.tipo, m.categoria),
    monto: m.monto,
    fecha: `${m.fecha}T00:00:00`,
    descripcion: m.descripcion,
  });

  const agregar = (m: Omit<Movimiento, 'id'>) => {
    if (!API_ACTIVA) {
      setLocales((prev) => [...prev, { ...m, id: Date.now() }]);
      return;
    }
    if (idUsuario === null) return;
    cuerpo(m)
      .then((datos) => api.crear(recurso(m.tipo), datos))
      .then(recargar)
      .catch(() => {});
  };

  const editar = (m: Movimiento) => {
    if (!API_ACTIVA) {
      setLocales((prev) => prev.map((x) => (x.id === m.id ? m : x)));
      return;
    }
    if (idUsuario === null) return;
    const anterior = remotos.find((x) => x.id === m.id);
    const { id, ...sinId } = m;
    cuerpo(sinId)
      .then(async (datos) => {
        if (anterior && anterior.tipo !== m.tipo) {
          // cambió de ingreso a gasto (o al revés): se borra de una tabla y se crea en la otra
          await api.borrar(recurso(anterior.tipo), idReal(anterior.id));
          await api.crear(recurso(m.tipo), datos);
        } else {
          await api.editar(recurso(m.tipo), idReal(id), datos);
        }
      })
      .then(recargar)
      .catch(() => {});
  };

  const eliminar = (id: number) => {
    if (!API_ACTIVA) {
      setLocales((prev) => prev.filter((x) => x.id !== id));
      return;
    }
    const existente = remotos.find((x) => x.id === id);
    if (!existente) return;
    api
      .borrar(recurso(existente.tipo), idReal(id))
      .then(recargar)
      .catch(() => {});
  };

  return (
    <DataContext.Provider value={{ movimientos, agregar, editar, eliminar }}>
      {children}
    </DataContext.Provider>
  );
}

export const useData = () => useContext(DataContext);
