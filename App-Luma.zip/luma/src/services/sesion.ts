import { useSyncExternalStore } from 'react';

// Guarda el id del usuario que inició sesión para que los demás contextos
// (movimientos, metas) sepan de quién cargar los datos.
let idActual: number | null = null;
const oyentes = new Set<() => void>();

export function fijarSesion(id: number | null) {
  if (id === idActual) return;
  idActual = id;
  oyentes.forEach((avisar) => avisar());
}

export function useSesionId() {
  return useSyncExternalStore(
    (avisar) => {
      oyentes.add(avisar);
      return () => {
        oyentes.delete(avisar);
      };
    },
    () => idActual,
    () => idActual
  );
}
