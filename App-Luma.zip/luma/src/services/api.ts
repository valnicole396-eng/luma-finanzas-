const URL_CONFIGURADA = process.env.EXPO_PUBLIC_API_URL ?? '';

// La app usa la API solo si EXPO_PUBLIC_API_URL tiene una dirección real.
// Si no, funciona como antes, guardando todo en el celular.
export const API_ACTIVA = /^https?:\/\//.test(URL_CONFIGURADA) && !URL_CONFIGURADA.includes('te-den');
const BASE = URL_CONFIGURADA.replace(/\/+$/, '');

export type UsuarioApi = { id_usuario: number; nombre: string; correo: string };
export type CategoriaApi = { id_categoria: number; nombre: string; tipo: string };
export type MovimientoApi = { id_usuario: number; id_categoria: number; monto: number; fecha: string; descripcion: string };
export type IngresoApi = MovimientoApi & { id_ingreso: number };
export type GastoApi = MovimientoApi & { id_gasto: number };
export type MetaApi = { id_meta: number; id_usuario: number; nombre: string; monto_objetivo: number; monto_actual: number; fecha_limite: string; estado: string };
export type PresupuestoApi = { id_presupuesto: number; id_usuario: number; monto_limite: number; periodo: string; fecha_inicio: string; fecha_fin: string };

async function pedir(ruta: string, opciones: RequestInit = {}) {
  const res = await fetch(`${BASE}/api/${ruta}`, {
    ...opciones,
    headers: { 'Content-Type': 'application/json' },
  });
  if (!res.ok) {
    let mensaje = `Error ${res.status}`;
    try {
      const cuerpo = await res.json();
      if (cuerpo?.mensaje) mensaje = cuerpo.mensaje;
    } catch {}
    throw new Error(mensaje);
  }
  return res;
}

export const api = {
  listar: async <T,>(recurso: string, idUsuario?: number): Promise<T[]> => {
    const filtro = idUsuario === undefined ? '' : `?idUsuario=${idUsuario}`;
    return (await pedir(`${recurso}${filtro}`)).json();
  },
  crear: async <T,>(recurso: string, datos: object): Promise<T> =>
    (await pedir(recurso, { method: 'POST', body: JSON.stringify(datos) })).json(),
  editar: async (recurso: string, id: number, datos: object) => {
    await pedir(`${recurso}/${id}`, { method: 'PUT', body: JSON.stringify(datos) });
  },
  borrar: async (recurso: string, id: number) => {
    await pedir(`${recurso}/${id}`, { method: 'DELETE' });
  },
  registrar: async (nombre: string, correo: string, contrasena: string): Promise<UsuarioApi> =>
    (await pedir('Usuario', { method: 'POST', body: JSON.stringify({ nombre, correo, contrasena }) })).json(),
  login: async (correo: string, contrasena: string): Promise<UsuarioApi> =>
    (await pedir('Usuario/login', { method: 'POST', body: JSON.stringify({ correo, contrasena }) })).json(),
};

// Convierte un error de red o del servidor en un mensaje para mostrar
export function mensajeError(e: unknown): string {
  const texto = e instanceof Error ? e.message : '';
  if (!texto || /network request failed|failed to fetch|load failed/i.test(texto)) {
    return 'No se pudo conectar con el servidor';
  }
  return texto;
}
