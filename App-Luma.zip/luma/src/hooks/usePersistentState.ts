import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export function usePersistentState<T>(key: string, initial: T) {
  const [valor, setValor] = useState<T>(initial);
  const [listo, setListo] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(key)
      .then((txt) => {
        if (txt != null) setValor(JSON.parse(txt));
      })
      .catch(() => {})
      .finally(() => setListo(true));
  }, [key]);

  useEffect(() => {
    if (listo) AsyncStorage.setItem(key, JSON.stringify(valor)).catch(() => {});
  }, [key, valor, listo]);

  return [valor, setValor, listo] as const;
}
