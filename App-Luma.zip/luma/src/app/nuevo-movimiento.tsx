import { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { colors } from '../theme/colors';
import { useData, categoriasGasto, categoriasIngreso } from '../context/DataContext';

export default function NuevoMovimiento() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { movimientos, agregar, editar, eliminar } = useData();
  const existente = movimientos.find((m) => String(m.id) === id);

  const [tipo, setTipo] = useState<'ingreso' | 'gasto'>(existente?.tipo ?? 'gasto');
  const [monto, setMonto] = useState(existente ? String(existente.monto) : '');
  const [categoria, setCategoria] = useState(existente?.categoria ?? 'Alimentación');
  const [descripcion, setDescripcion] = useState(existente?.descripcion ?? '');
  const [fecha, setFecha] = useState(existente?.fecha ?? new Date().toLocaleDateString('en-CA'));
  const [error, setError] = useState('');

  const categorias = tipo === 'gasto' ? categoriasGasto : categoriasIngreso;

  const cambiarTipo = (t: 'ingreso' | 'gasto') => {
    setTipo(t);
    setCategoria(t === 'gasto' ? categoriasGasto[0] : categoriasIngreso[0]);
  };

  const guardar = () => {
    const valor = Number(monto.replace(/[^0-9]/g, ''));
    if (!valor || valor <= 0) {
      setError('Escribe un monto mayor a 0');
      return;
    }
    const datos = { tipo, monto: valor, categoria, descripcion, fecha };
    if (existente) editar({ ...datos, id: existente.id });
    else agregar(datos);
    router.back();
  };

  const borrar = () => {
    if (existente) eliminar(existente.id);
    router.back();
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.title}>{existente ? 'Editar movimiento' : 'Nuevo movimiento'}</Text>

        <View style={s.toggle}>
          <Pressable style={[s.toggleBtn, tipo === 'gasto' && s.toggleOn]} onPress={() => cambiarTipo('gasto')}>
            <Text style={[s.toggleTxt, tipo === 'gasto' && s.toggleTxtOn]}>Gasto</Text>
          </Pressable>
          <Pressable style={[s.toggleBtn, tipo === 'ingreso' && s.toggleOn]} onPress={() => cambiarTipo('ingreso')}>
            <Text style={[s.toggleTxt, tipo === 'ingreso' && s.toggleTxtOn]}>Ingreso</Text>
          </Pressable>
        </View>

        <Text style={s.label}>Monto</Text>
        <TextInput style={s.input} value={monto} onChangeText={(t) => { setMonto(t); setError(''); }} keyboardType="numeric" placeholder="Ej: 50000" placeholderTextColor={colors.light} />
        {error ? <Text style={s.error}>{error}</Text> : null}

        <Text style={s.label}>Categoría</Text>
        <View style={s.chips}>
          {categorias.map((c) => (
            <Pressable key={c} style={[s.chip, categoria === c && s.chipOn]} onPress={() => setCategoria(c)}>
              <Text style={[s.chipTxt, categoria === c && s.chipTxtOn]}>{c}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={s.label}>Fecha (AAAA-MM-DD)</Text>
        <TextInput style={s.input} value={fecha} onChangeText={setFecha} placeholderTextColor={colors.light} />

        <Text style={s.label}>Descripción</Text>
        <TextInput style={s.input} value={descripcion} onChangeText={setDescripcion} placeholder="Opcional" placeholderTextColor={colors.light} />

        <Pressable style={s.save} onPress={guardar}>
          <Text style={s.saveTxt}>Guardar</Text>
        </Pressable>
        {existente ? (
          <Pressable style={s.del} onPress={borrar}>
            <Text style={s.delTxt}>Eliminar</Text>
          </Pressable>
        ) : null}
        <Pressable style={s.cancel} onPress={() => router.back()}>
          <Text style={s.cancelTxt}>Cancelar</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: colors.primary, marginBottom: 16 },
  toggle: { flexDirection: 'row', backgroundColor: '#fff', borderRadius: 14, padding: 4, marginBottom: 8 },
  toggleBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  toggleOn: { backgroundColor: colors.primary },
  toggleTxt: { color: colors.primary, fontWeight: '600' },
  toggleTxtOn: { color: '#fff' },
  label: { color: colors.primary, fontWeight: '600', marginTop: 14, marginBottom: 6 },
  input: { backgroundColor: '#fff', borderRadius: 12, padding: 12, color: colors.text, fontSize: 16 },
  error: { color: '#C0392B', marginTop: 6 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20, backgroundColor: '#fff' },
  chipOn: { backgroundColor: colors.primary },
  chipTxt: { color: colors.primary },
  chipTxtOn: { color: '#fff' },
  save: { backgroundColor: colors.primary, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 24 },
  saveTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  del: { borderWidth: 1.5, borderColor: '#C0392B', borderRadius: 14, padding: 12, alignItems: 'center', marginTop: 12 },
  delTxt: { color: '#C0392B', fontWeight: 'bold' },
  cancel: { padding: 12, alignItems: 'center', marginTop: 6 },
  cancelTxt: { color: colors.medium },
});
