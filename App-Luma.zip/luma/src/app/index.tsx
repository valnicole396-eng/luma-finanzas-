import { Redirect } from "expo-router";
import { useAuth } from "../context/AuthContext";

export default function Index() {
  const { usuario, listo } = useAuth();
  if (!listo) return null;
  return <Redirect href={usuario ? "/inicio" : "/login"} />;
}
