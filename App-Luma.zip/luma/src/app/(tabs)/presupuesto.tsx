import { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Redirect } from 'expo-router';
import { colors } from '../../theme/colors';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { usePersistentState } from '../../hooks/usePersistentState';
import { API_ACTIVA, api, mensajeError, PresupuestoApi } from '../../services/api';
import { useSesionId } from '../../services/sesion';

const cop = (n: number) => '$' + Math.round(n).toLocaleString('es-CO');
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

export default function Presupuesto() {
  const { usuario, listo } = useAuth();
  const { movimientos } = useData();
  const idUsuario = useSesionId();
  const [limiteLocal, setLimiteLocal] = usePersistentState<number>('luma:presupuesto', 0);
  const [remoto, setRemoto] = useState<PresupuestoApi | null>(null);
  const [texto, setTexto] = useState('');
  const [mensaje, setMensaje] = useState('');

  const ahora = new Date();
  const mes = ahora.toLocaleDateString('en-CA').slice(0, 7);
  const inicio = `${mes}-01`;
  const fin = new Date(ahora.getFullYear(), ahora.getMonth() + 1, 0).toLocaleDateString('en-CA');

  useEffect(() => {
    if (!API_ACTIVA || idUsuario === null) {
      setRemoto(null);
      return;
    }
    api
      .listar<PresupuestoApi>('Presupuesto', idUsuario)
      .then((lista) => setRemoto(lista.find((p) => String(p.fecha_inicio).slice(0, 7) === mes) ?? null))
      .catch(() => {});
  }, [idUsuario]);

  if (!listo) return null;
  if (!usuario) return <Redirect href="/login" />;

  const limite = API_ACTIVA ? Number(remoto?.monto_limite ?? 0) : limiteLocal;
  const delMes = movimientos.filter((m) => m.tipo === 'gasto' && m.fecha.startsWith(mes));
  const gastado = delMes.reduce((a, m) => a + m.monto, 0);
  const porCategoria = Object.entries(
    delMes.reduce<Record<string, number>>((acc, m) => {
      acc[m.categoria] = (acc[m.categoria] ?? 0) + m.monto;
      return acc;
    }, {})
  ).sort((a, b) => b[1] - a[1]);
  const porcentaje = limite > 0 ? gastado / limite : 0;
  const colorBarra = porcentaje >= 1 ? '#C0392B' : porcentaje >= 0.8 ? '#D98E04' : colors.green;
  const restante = limite - gastado;

  const guardar = async () => {
    const valor = Number(texto.replace(/\D/g, ''));
    if (!valor) return setMensaje('Escribe un monto mayor a cero');
    if (!API_ACTIVA) {
      setLimiteLocal(valor);
    } else if (idUsuario !== null) {
      const datos = {
        id_usuario: idUsuario,
        monto_limite: valor,
        periodo: 'mensual',
        fecha_inicio: `${inicio}T00:00:00`,
        fecha_fin: `${fin}T00:00:00`,
      };
      try {
        if (remoto) {
          await api.editar('Presupuesto', remoto.id_presupuesto, datos);
          setRemoto({ ...remoto, monto_limite: valor });
        } else {
          setRemoto(await api.crear<PresupuestoApi>('Presupuesto', datos));
        }
      } catch (e) {
        return setMensaje(mensajeError(e));
      }
    }
    setTexto('');
    setMensaje('Presupuesto guardado');
  };

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
        <View style={s.wrap}>
          <Text style={s.title}>Presupuesto</Text>
          <Text style={s.sub}>{MESES[ahora.getMonth()].charAt(0).toUpperCase() + MESES[ahora.getMonth()].slice(1)} de {ahora.getFullYear()}</Text>

          <View style={s.card}>
            <Text style={s.label}>Gastado este mes</Text>
            <Text style={s.big}>{cop(gastado)}</Text>
            {limite > 0 ? (
              <>
                <View style={s.track}>
                  <View style={[s.fill, { width: `${Math.min(porcentaje, 1) * 100}%`, backgroundColor: colorBarra }]} />
                </View>
                <Text style={s.nota}>
                  {restante >= 0
                    ? `Te quedan ${cop(restante)} de ${cop(limite)}`
                    : `Te pasaste por ${cop(-restante)} del límite de ${cop(limite)}`}
                </Text>
              </>
            ) : (
              <Text style={s.nota}>Define un límite mensual para ver tu avance</Text>
            )}
          </View>

          <View style={s.card}>
            <Text style={s.label}>{limite > 0 ? 'Cambiar límite mensual' : 'Límite mensual'}</Text>
            <TextInput
              style={s.input}
              value={texto}
              onChangeText={(t) => { setTexto(t); setMensaje(''); }}
              placeholder="Ej: 1500000"
              placeholderTextColor={colors.light}
              keyboardType="numeric"
            />
            {mensaje ? <Text style={s.nota}>{mensaje}</Text> : null}
            <Pressable style={s.btn} onPress={guardar}>
              <Text style={s.btnTxt}>Guardar presupuesto</Text>
            </Pressable>
          </View>

          <View style={s.card}>
            <Text style={s.label}>Gastos por categoría</Text>
            {porCategoria.length === 0 ? (
              <Text style={s.nota}>Aún no hay gastos este mes</Text>
            ) : (
              porCategoria.map(([nombre, monto]) => (
                <View key={nombre} style={s.fila}>
                  <View style={s.filaTop}>
                    <Text style={s.cat}>{nombre}</Text>
                    <Text style={s.cat}>{cop(monto)}</Text>
                  </View>
                  <View style={s.trackFino}>
                    <View style={[s.fill, { width: `${(monto / gastado) * 100}%`, backgroundColor: colors.medium }]} />
                  </View>
                </View>
              ))
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { flexGrow: 1, alignItems: 'center', padding: 20 },
  wrap: { width: '100%', maxWidth: 560 },
  title: { fontSize: 26, fontWeight: 'bold', color: colors.primary },
  sub: { color: colors.muted, marginTop: 2, marginBottom: 16 },
  card: { backgroundColor: colors.card, borderRadius: 20, padding: 18, marginBottom: 14 },
  label: { color: colors.primary, fontWeight: '600', marginBottom: 6 },
  big: { color: colors.text, fontSize: 30, fontWeight: 'bold' },
  track: { height: 14, borderRadius: 7, backgroundColor: colors.bg, marginTop: 12, overflow: 'hidden' },
  trackFino: { height: 8, borderRadius: 4, backgroundColor: colors.bg, marginTop: 4, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 7 },
  nota: { color: colors.muted, marginTop: 8 },
  input: { backgroundColor: colors.bg, borderRadius: 12, padding: 12, color: colors.text, fontSize: 16 },
  btn: { backgroundColor: colors.primary, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 14 },
  btnTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  fila: { marginTop: 10 },
  filaTop: { flexDirection: 'row', justifyContent: 'space-between' },
  cat: { color: colors.text },
});
