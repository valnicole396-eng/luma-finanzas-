import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { colors } from '../../theme/colors';
import { useData } from '../../context/DataContext';

const cop = (n: number) => '$' + n.toLocaleString('es-CO');
const MESES = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
const ALTO = 150;

export default function Graficos() {
  const router = useRouter();
  const { movimientos } = useData();

  const porMes: Record<string, { ing: number; gas: number }> = {};
  movimientos.forEach((m) => {
    const clave = m.fecha.slice(0, 7);
    if (!porMes[clave]) porMes[clave] = { ing: 0, gas: 0 };
    if (m.tipo === 'ingreso') porMes[clave].ing += m.monto;
    else porMes[clave].gas += m.monto;
  });
  const claves = Object.keys(porMes).sort().slice(-6);
  const max = Math.max(1, ...claves.flatMap((c) => [porMes[c].ing, porMes[c].gas]));

  const historial = [...movimientos].sort(
    (a, b) => b.fecha.localeCompare(a.fecha) || b.id - a.id
  );

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.title}>Gráficos</Text>

        <View style={s.chartCard}>
          <Text style={s.section}>Ingresos vs gastos por mes</Text>
          <View style={s.legend}>
            <View style={s.legendItem}><View style={[s.dot, { backgroundColor: colors.light }]} /><Text style={s.legendTxt}>Ingresos</Text></View>
            <View style={s.legendItem}><View style={[s.dot, { backgroundColor: colors.primary }]} /><Text style={s.legendTxt}>Gastos</Text></View>
          </View>
          <View style={s.chart}>
            {claves.map((c) => {
              const mes = MESES[Number(c.slice(5, 7)) - 1];
              return (
                <View key={c} style={s.group}>
                  <View style={s.bars}>
                    <View style={[s.barIng, { height: Math.max(3, (porMes[c].ing / max) * ALTO) }]} />
                    <View style={[s.barGas, { height: Math.max(3, (porMes[c].gas / max) * ALTO) }]} />
                  </View>
                  <Text style={s.mes}>{mes}</Text>
                </View>
              );
            })}
          </View>
        </View>

        <Text style={s.section}>Historial</Text>
        {historial.map((m) => (
          <Pressable
            key={m.id}
            style={s.mov}
            onPress={() => router.push({ pathname: '/nuevo-movimiento', params: { id: String(m.id) } })}
          >
            <View style={{ flex: 1 }}>
              <Text style={s.movName}>{m.descripcion || m.categoria}</Text>
              <Text style={s.movSub}>{m.categoria} · {m.fecha}</Text>
            </View>
            <Text style={[s.movMonto, { color: m.tipo === 'ingreso' ? '#2E7D32' : colors.primary }]}>
              {m.tipo === 'ingreso' ? '+' : '-'}{cop(m.monto)}
            </Text>
          </Pressable>
        ))}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20 },
  title: { fontSize: 26, fontWeight: 'bold', color: colors.primary, marginBottom: 16 },
  section: { fontSize: 18, fontWeight: 'bold', color: colors.primary, marginBottom: 12 },
  chartCard: { backgroundColor: '#fff', borderRadius: 20, padding: 16, marginBottom: 22 },
  legend: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dot: { width: 12, height: 12, borderRadius: 6 },
  legendTxt: { color: colors.medium, fontSize: 13 },
  chart: { flexDirection: 'row', justifyContent: 'space-around', alignItems: 'flex-end' },
  group: { alignItems: 'center' },
  bars: { flexDirection: 'row', alignItems: 'flex-end', gap: 6, height: ALTO },
  barIng: { width: 26, backgroundColor: colors.light, borderTopLeftRadius: 6, borderTopRightRadius: 6 },
  barGas: { width: 26, backgroundColor: colors.primary, borderTopLeftRadius: 6, borderTopRightRadius: 6 },
  mes: { color: colors.primary, marginTop: 6, fontWeight: '600' },
  mov: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10 },
  movName: { color: colors.primary, fontWeight: '600', fontSize: 15 },
  movSub: { color: colors.medium, fontSize: 12, marginTop: 2 },
  movMonto: { fontWeight: 'bold', fontSize: 15 },
});
