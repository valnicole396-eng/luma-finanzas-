import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useWindowDimensions } from 'react-native';
import { colors } from '../../theme/colors';

const icono = (name: any) => ({ color, size }: any) => (
  <Ionicons name={name} color={color} size={size} />
);

export default function TabsLayout() {
  const { width } = useWindowDimensions();
  const ancho = width >= 900;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarPosition: ancho ? 'left' : 'bottom',
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.light,
        tabBarStyle: { backgroundColor: colors.bg },
      }}
    >
      <Tabs.Screen name="inicio" options={{ title: 'Inicio', tabBarIcon: icono('home') }} />
      <Tabs.Screen name="graficos" options={{ title: 'Gráficos', tabBarIcon: icono('bar-chart') }} />
      <Tabs.Screen name="metas" options={{ title: 'Metas', tabBarIcon: icono('flag') }} />
      <Tabs.Screen name="presupuesto" options={{ title: 'Presupuesto', tabBarIcon: icono('wallet') }} />
      <Tabs.Screen name="perfil" options={{ title: 'Perfil', tabBarIcon: icono('person') }} />
    </Tabs>
  );
}
