import { useState } from 'react';
import { View, Text, TextInput, Pressable, Image, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Redirect, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../theme/colors';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useMetas } from '../../context/MetasContext';

const cop = (n: number) => '$' + n.toLocaleString('es-CO');

export default function Perfil() {
  const router = useRouter();
  const { usuario, listo, actualizar, salir } = useAuth();
  const { movimientos } = useData();
  const { metas } = useMetas();
  const [editando, setEditando] = useState(false);
  const [nuevoNombre, setNuevoNombre] = useState('');

  if (!listo) return null;
  if (!usuario) return <Redirect href="/login" />;

  const ingresos = movimientos.filter((m) => m.tipo === 'ingreso').reduce((a, m) => a + m.monto, 0);
  const gastos = movimientos.filter((m) => m.tipo === 'gasto').reduce((a, m) => a + m.monto, 0);
  const ahorrado = metas.reduce((a, m) => a + m.abonos.reduce((x, ab) => x + ab.monto, 0), 0);

  const elegirFoto = async () => {
    const res = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (!res.canceled) actualizar({ foto: res.assets[0].uri });
  };

  const empezarEditar = () => {
    setNuevoNombre(usuario.nombre);
    setEditando(true);
  };

  const guardarNombre = () => {
    if (nuevoNombre.trim()) actualizar({ nombre: nuevoNombre.trim() });
    setEditando(false);
  };

  const cerrarSesion = () => {
    salir();
    router.replace('/login');
  };

  const stats = [
    { icono: 'wallet', label: 'Saldo', valor: cop(ingresos - gastos) },
    { icono: 'swap-vertical', label: 'Movimientos', valor: String(movimientos.length) },
    { icono: 'flag', label: 'Metas activas', valor: String(metas.length) },
    { icono: 'trending-up', label: 'Ahorrado en metas', valor: cop(ahorrado) },
  ];

  return (
    <SafeAreaView style={s.safe} edges={['top']}>
      <ScrollView contentContainerStyle={s.content}>
        <View style={s.wrap}>
          <Text style={s.title}>Perfil</Text>

          <View style={s.hero}>
            <Pressable onPress={elegirFoto} style={s.avatarBox}>
              {usuario.foto ? (
                <Image source={{ uri: usuario.foto }} style={s.avatarImg} />
              ) : (
                <View style={s.avatar}>
                  <Text style={s.avatarTxt}>{usuario.nombre.charAt(0).toUpperCase()}</Text>
                </View>
              )}
              <View style={s.camara}>
                <Ionicons name="camera" size={16} color={colors.primary} />
              </View>
            </Pressable>

            {editando ? (
              <View style={s.editRow}>
                <TextInput
                  style={s.editInput}
                  value={nuevoNombre}
                  onChangeText={setNuevoNombre}
                  autoFocus
                  placeholder="Tu nombre"
                  placeholderTextColor={colors.light}
                />
                <Pressable style={s.okBtn} onPress={guardarNombre}>
                  <Ionicons name="checkmark" size={20} color={colors.primary} />
                </Pressable>
              </View>
            ) : (
              <Pressable style={s.nombreRow} onPress={empezarEditar}>
                <Text style={s.nombre}>{usuario.nombre}</Text>
                <Ionicons name="create-outline" size={18} color={colors.light} />
              </Pressable>
            )}
            <Text style={s.correo}>{usuario.correo}</Text>
            <Text style={s.desde}>Miembro desde {usuario.desde}</Text>
          </View>

          <Text style={s.section}>Tu resumen</Text>
          <View style={s.grid}>
            {stats.map((st) => (
              <View key={st.label} style={s.stat}>
                <View style={s.statIcon}>
                  <Ionicons name={st.icono as any} size={18} color={colors.primary} />
                </View>
                <Text style={s.statValor}>{st.valor}</Text>
                <Text style={s.statLabel}>{st.label}</Text>
              </View>
            ))}
          </View>

          <Pressable style={s.logout} onPress={cerrarSesion}>
            <Ionicons name="log-out-outline" size={20} color={colors.primary} />
            <Text style={s.logoutTxt}>Cerrar sesión</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20, alignItems: 'center' },
  wrap: { width: '100%', maxWidth: 720 },
  title: { fontSize: 26, fontWeight: 'bold', color: colors.primary, marginBottom: 16 },
  hero: { backgroundColor: colors.primary, borderRadius: 28, padding: 24, alignItems: 'center', marginBottom: 24 },
  avatarBox: { width: 110, height: 110 },
  avatar: { width: 110, height: 110, borderRadius: 55, backgroundColor: colors.medium, alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: colors.light },
  avatarImg: { width: 110, height: 110, borderRadius: 55, borderWidth: 4, borderColor: colors.light },
  avatarTxt: { color: '#fff', fontSize: 48, fontWeight: 'bold' },
  camara: { position: 'absolute', right: 0, bottom: 2, width: 32, height: 32, borderRadius: 16, backgroundColor: colors.light, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: colors.primary },
  nombreRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  nombre: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  editRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
  editInput: { backgroundColor: '#fff', borderRadius: 12, paddingVertical: 8, paddingHorizontal: 12, color: colors.text, fontSize: 18, minWidth: 180 },
  okBtn: { backgroundColor: colors.light, width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  correo: { color: colors.light, marginTop: 4, fontSize: 15 },
  desde: { color: colors.light, marginTop: 6, fontSize: 12, opacity: 0.8 },
  section: { fontSize: 18, fontWeight: 'bold', color: colors.primary, marginBottom: 12 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  stat: { width: '48%', flexGrow: 1, backgroundColor: '#fff', borderRadius: 18, padding: 16 },
  statIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
  statValor: { color: colors.primary, fontSize: 18, fontWeight: 'bold' },
  statLabel: { color: colors.medium, fontSize: 13, marginTop: 2 },
  logout: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: colors.primary, borderRadius: 14, padding: 14, marginTop: 28, marginBottom: 20 },
  logoutTxt: { color: colors.primary, fontWeight: 'bold', fontSize: 16 },
});
