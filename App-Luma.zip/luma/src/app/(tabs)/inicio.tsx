import { View, Text, ScrollView, Pressable, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { colors } from '../../theme/colors';
import { useData } from '../../context/DataContext';
import Columnas from '../../components/Columnas';

const cop = (n: number) => '$' + n.toLocaleString('es-CO');

export default function Inicio() {
  const router = useRouter();
  const { movimientos } = useData();

  const ingresos = movimientos.filter((m) => m.tipo === 'ingreso').reduce((a, m) => a + m.monto, 0);
  const gastos = movimientos.filter((m) => m.tipo === 'gasto').reduce((a, m) => a + m.monto, 0);
  const saldo = ingresos - gastos;

  const porCat: Record<string, number> = {};
  movimientos
    .filter((m) => m.tipo === 'gasto')
    .forEach((m) => { porCat[m.categoria] = (porCat[m.categoria] || 0) + m.monto; });
  const cats = Object.entries(porCat).sort((a, b) => b[1] - a[1]);
  const max = Math.max(1, ...cats.map((c) => c[1]));

  const recientes = [...movimientos]
    .sort((a, b) => b.fecha.localeCompare(a.fecha) || b.id - a.id)
    .slice(0, 6);

  const izquierda = (
    <View>
      <View style={s.card}>
        <Text style={s.cardLabel}>Saldo total</Text>
        <Text style={s.saldo}>{cop(saldo)}</Text>
      </View>

      <View style={s.row}>
        <View style={s.mini}>
          <Text style={s.miniLabel}>Ingresos</Text>
          <Text style={s.miniValue}>{cop(ingresos)}</Text>
        </View>
        <View style={s.mini}>
          <Text style={s.miniLabel}>Gastos</Text>
          <Text style={s.miniValue}>{cop(gastos)}</Text>
        </View>
      </View>

      <Text style={s.section}>Gastos por categoría</Text>
      {cats.length === 0 ? <Text style={s.vacio}>Aún no hay gastos</Text> : null}
      {cats.map(([nombre, monto]) => (
        <View key={nombre} style={s.item}>
          <View style={s.itemHead}>
            <Text style={s.itemName}>{nombre}</Text>
            <Text style={s.itemName}>{cop(monto)}</Text>
          </View>
          <View style={s.track}>
            <View style={[s.bar, { width: `${(monto / max) * 100}%` as any }]} />
          </View>
        </View>
      ))}
    </View>
  );

  const derecha = (
    <View>
      <Text style={s.section}>Movimientos recientes</Text>
      {recientes.map((m) => (
        <Pressable
          key={m.id}
          style={s.mov}
          onPress={() => router.push({ pathname: '/nuevo-movimiento', params: { id: String(m.id) } })}
        >
          <View style={{ flex: 1 }}>
            <Text style={s.movName}>{m.descripcion || m.categoria}</Text>
            <Text style={s.movSub}>{m.categoria} · {m.fecha}</Text>
          </View>
          <Text style={[s.movMonto, { color: m.tipo === 'ingreso' ? '#2E7D32' : colors.primary }]}>
            {m.tipo === 'ingreso' ? '+' : '-'}{cop(m.monto)}
          </Text>
        </Pressable>
      ))}
    </View>
  );

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.title}>Resumen</Text>
        <Columnas izquierda={izquierda} derecha={derecha} />
        <View style={{ height: 90 }} />
      </ScrollView>

      <Pressable style={s.fab} onPress={() => router.push('/nuevo-movimiento')}>
        <Text style={s.fabTxt}>+</Text>
      </Pressable>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20 },
  title: { fontSize: 26, fontWeight: 'bold', color: colors.primary, marginBottom: 16 },
  card: { backgroundColor: colors.primary, borderRadius: 20, padding: 20, marginBottom: 14 },
  cardLabel: { color: colors.light, fontSize: 14 },
  saldo: { color: '#fff', fontSize: 34, fontWeight: 'bold', marginTop: 4 },
  row: { flexDirection: 'row', gap: 12, marginBottom: 22 },
  mini: { flex: 1, backgroundColor: '#fff', borderRadius: 16, padding: 14 },
  miniLabel: { color: colors.medium, fontSize: 13 },
  miniValue: { color: colors.primary, fontSize: 18, fontWeight: 'bold', marginTop: 4 },
  section: { fontSize: 18, fontWeight: 'bold', color: colors.primary, marginBottom: 12 },
  vacio: { color: colors.medium, marginBottom: 12 },
  item: { marginBottom: 14 },
  itemHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  itemName: { color: colors.primary, fontSize: 14 },
  track: { height: 10, backgroundColor: colors.light, borderRadius: 5, overflow: 'hidden' },
  bar: { height: 10, backgroundColor: colors.primary, borderRadius: 5 },
  mov: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10 },
  movName: { color: colors.primary, fontWeight: '600', fontSize: 15 },
  movSub: { color: colors.medium, fontSize: 12, marginTop: 2 },
  movMonto: { fontWeight: 'bold', fontSize: 15 },
  fab: { position: 'absolute', right: 20, bottom: 20, width: 58, height: 58, borderRadius: 29, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', elevation: 6 },
  fabTxt: { color: '#fff', fontSize: 32, lineHeight: 36 },
});
