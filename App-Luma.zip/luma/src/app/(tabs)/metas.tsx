import { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors } from '../../theme/colors';
import { useMetas } from '../../context/MetasContext';

const cop = (n: number) => '$' + n.toLocaleString('es-CO');
const soloNumeros = (t: string) => Number(t.replace(/[^0-9]/g, ''));

export default function Metas() {
  const { metas, agregarMeta, abonar, eliminarMeta } = useMetas();

  const [formAbierto, setFormAbierto] = useState(false);
  const [nombre, setNombre] = useState('');
  const [objetivo, setObjetivo] = useState('');
  const [fecha, setFecha] = useState('');
  const [error, setError] = useState('');

  const [abonandoId, setAbonandoId] = useState<number | null>(null);
  const [abonoMonto, setAbonoMonto] = useState('');

  const crearMeta = () => {
    const valor = soloNumeros(objetivo);
    if (!nombre.trim() || !valor) {
      setError('Escribe un nombre y un monto objetivo');
      return;
    }
    agregarMeta({ nombre: nombre.trim(), montoObjetivo: valor, fechaLimite: fecha });
    setNombre(''); setObjetivo(''); setFecha(''); setError(''); setFormAbierto(false);
  };

  const confirmarAbono = (id: number) => {
    const valor = soloNumeros(abonoMonto);
    if (valor > 0) abonar(id, valor);
    setAbonoMonto('');
    setAbonandoId(null);
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.content}>
        <View style={s.header}>
          <Text style={s.title}>Metas de ahorro</Text>
          <Pressable style={s.addBtn} onPress={() => setFormAbierto(!formAbierto)}>
            <Text style={s.addTxt}>{formAbierto ? 'Cerrar' : '+ Nueva'}</Text>
          </Pressable>
        </View>

        {formAbierto ? (
          <View style={s.form}>
            <Text style={s.label}>Nombre de la meta</Text>
            <TextInput style={s.input} value={nombre} onChangeText={setNombre} placeholder="Ej: Viaje" placeholderTextColor={colors.light} />
            <Text style={s.label}>Monto objetivo</Text>
            <TextInput style={s.input} value={objetivo} onChangeText={setObjetivo} keyboardType="numeric" placeholder="Ej: 1500000" placeholderTextColor={colors.light} />
            <Text style={s.label}>Fecha límite (AAAA-MM-DD)</Text>
            <TextInput style={s.input} value={fecha} onChangeText={setFecha} placeholder="Ej: 2026-12-20" placeholderTextColor={colors.light} />
            {error ? <Text style={s.error}>{error}</Text> : null}
            <Pressable style={s.save} onPress={crearMeta}>
              <Text style={s.saveTxt}>Crear meta</Text>
            </Pressable>
          </View>
        ) : null}

        {metas.length === 0 ? <Text style={s.vacio}>Aún no tienes metas. Crea la primera con "+ Nueva".</Text> : null}

        {metas.map((m) => {
          const abonado = m.abonos.reduce((a, x) => a + x.monto, 0);
          const pct = Math.min(100, Math.round((abonado / m.montoObjetivo) * 100));
          const completa = abonado >= m.montoObjetivo;
          return (
            <View key={m.id} style={s.card}>
              <View style={s.cardHead}>
                <Text style={s.cardName}>{m.nombre}</Text>
                <Text style={s.pct}>{pct}%</Text>
              </View>
              <View style={s.track}>
                <View style={[s.bar, { width: `${pct}%` as any }]} />
              </View>
              <Text style={s.cardSub}>
                {cop(abonado)} de {cop(m.montoObjetivo)}
                {m.fechaLimite ? ` · hasta ${m.fechaLimite}` : ''}
              </Text>
              {completa ? <Text style={s.ok}>¡Meta cumplida!</Text> : null}

              {abonandoId === m.id ? (
                <View style={s.abonoRow}>
                  <TextInput
                    style={[s.input, { flex: 1 }]}
                    value={abonoMonto}
                    onChangeText={setAbonoMonto}
                    keyboardType="numeric"
                    placeholder="Monto del abono"
                    placeholderTextColor={colors.light}
                    autoFocus
                  />
                  <Pressable style={s.okBtn} onPress={() => confirmarAbono(m.id)}>
                    <Text style={s.okTxt}>Abonar</Text>
                  </Pressable>
                </View>
              ) : (
                <View style={s.actions}>
                  <Pressable style={s.abonarBtn} onPress={() => { setAbonandoId(m.id); setAbonoMonto(''); }}>
                    <Text style={s.abonarTxt}>+ Abonar</Text>
                  </Pressable>
                  <Pressable onPress={() => eliminarMeta(m.id)}>
                    <Text style={s.delTxt}>Eliminar</Text>
                  </Pressable>
                </View>
              )}
            </View>
          );
        })}
        <View style={{ height: 20 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { padding: 20 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  title: { fontSize: 26, fontWeight: 'bold', color: colors.primary },
  addBtn: { backgroundColor: colors.primary, borderRadius: 20, paddingVertical: 8, paddingHorizontal: 16 },
  addTxt: { color: '#fff', fontWeight: 'bold' },
  form: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 16 },
  label: { color: colors.primary, fontWeight: '600', marginTop: 10, marginBottom: 6 },
  input: { backgroundColor: colors.bg, borderRadius: 12, padding: 12, color: colors.text, fontSize: 16 },
  error: { color: '#C0392B', marginTop: 8 },
  save: { backgroundColor: colors.primary, borderRadius: 14, padding: 12, alignItems: 'center', marginTop: 16 },
  saveTxt: { color: '#fff', fontWeight: 'bold' },
  vacio: { color: colors.medium, marginTop: 10 },
  card: { backgroundColor: '#fff', borderRadius: 18, padding: 16, marginBottom: 14 },
  cardHead: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  cardName: { color: colors.primary, fontSize: 18, fontWeight: 'bold' },
  pct: { color: colors.primary, fontSize: 18, fontWeight: 'bold' },
  track: { height: 12, backgroundColor: colors.light, borderRadius: 6, overflow: 'hidden' },
  bar: { height: 12, backgroundColor: colors.primary, borderRadius: 6 },
  cardSub: { color: colors.medium, marginTop: 8, fontSize: 13 },
  ok: { color: '#2E7D32', fontWeight: 'bold', marginTop: 6 },
  actions: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 12 },
  abonarBtn: { backgroundColor: colors.bg, borderRadius: 20, paddingVertical: 8, paddingHorizontal: 16 },
  abonarTxt: { color: colors.primary, fontWeight: 'bold' },
  delTxt: { color: '#C0392B' },
  abonoRow: { flexDirection: 'row', gap: 10, alignItems: 'center', marginTop: 12 },
  okBtn: { backgroundColor: colors.primary, borderRadius: 12, paddingVertical: 12, paddingHorizontal: 16 },
  okTxt: { color: '#fff', fontWeight: 'bold' },
});
