import { Stack } from "expo-router";
import { AuthProvider } from "../context/AuthContext";
import { DataProvider } from "../context/DataContext";
import { MetasProvider } from "../context/MetasContext";

export default function RootLayout() {
  return (
    <AuthProvider>
      <DataProvider>
        <MetasProvider>
          <Stack screenOptions={{ headerShown: false }} />
        </MetasProvider>
      </DataProvider>
    </AuthProvider>
  );
}
