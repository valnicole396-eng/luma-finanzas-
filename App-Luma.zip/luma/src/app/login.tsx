import { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { colors } from '../theme/colors';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const router = useRouter();
  const { registrar, ingresar } = useAuth();
  const [crear, setCrear] = useState(false);
  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [clave, setClave] = useState('');
  const [error, setError] = useState('');
  const [cargando, setCargando] = useState(false);

  const enviar = async () => {
    if (cargando) return;
    if (crear && !nombre.trim()) return setError('Escribe tu nombre');
    if (!/^\S+@\S+\.\S+$/.test(correo.trim())) return setError('Escribe un correo válido');
    if (clave.length < 4) return setError('La contraseña debe tener mínimo 4 caracteres');
    setCargando(true);
    const mensaje = await (crear ? registrar(nombre, correo, clave) : ingresar(correo, clave));
    setCargando(false);
    if (mensaje) return setError(mensaje);
    router.replace('/inicio');
  };

  const cambiarModo = () => {
    setCrear(!crear);
    setError('');
  };

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
        <View style={s.box}>
          <View style={s.logo}>
            <Text style={s.logoTxt}>L</Text>
          </View>
          <Text style={s.brand}>Luma</Text>
          <Text style={s.sub}>{crear ? 'Crea tu cuenta' : 'Inicia sesión para continuar'}</Text>

          <View style={s.card}>
            {crear ? (
              <>
                <Text style={s.label}>Nombre</Text>
                <TextInput style={s.input} value={nombre} onChangeText={(t) => { setNombre(t); setError(''); }} placeholder="Tu nombre" placeholderTextColor={colors.light} />
              </>
            ) : null}

            <Text style={s.label}>Correo</Text>
            <TextInput style={s.input} value={correo} onChangeText={(t) => { setCorreo(t); setError(''); }} placeholder="correo@ejemplo.com" placeholderTextColor={colors.light} autoCapitalize="none" keyboardType="email-address" />

            <Text style={s.label}>Contraseña</Text>
            <TextInput style={s.input} value={clave} onChangeText={(t) => { setClave(t); setError(''); }} placeholder="Mínimo 4 caracteres" placeholderTextColor={colors.light} secureTextEntry />

            {error ? <Text style={s.error}>{error}</Text> : null}

            <Pressable style={[s.btn, cargando && { opacity: 0.6 }]} onPress={enviar} disabled={cargando}>
              <Text style={s.btnTxt}>{cargando ? 'Cargando...' : crear ? 'Crear cuenta' : 'Iniciar sesión'}</Text>
            </Pressable>
          </View>

          <Pressable onPress={cambiarModo} style={s.link}>
            <Text style={s.linkTxt}>
              {crear ? '¿Ya tienes cuenta? ' : '¿No tienes cuenta? '}
              <Text style={s.linkBold}>{crear ? 'Inicia sesión' : 'Regístrate'}</Text>
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { flexGrow: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  box: { width: '100%', maxWidth: 420, alignItems: 'center' },
  logo: { width: 84, height: 84, borderRadius: 42, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' },
  logoTxt: { color: '#fff', fontSize: 40, fontWeight: 'bold' },
  brand: { fontSize: 30, fontWeight: 'bold', color: colors.primary, marginTop: 12 },
  sub: { color: colors.medium, marginTop: 4, marginBottom: 22 },
  card: { width: '100%', backgroundColor: '#fff', borderRadius: 20, padding: 20 },
  label: { color: colors.primary, fontWeight: '600', marginTop: 10, marginBottom: 6 },
  input: { backgroundColor: colors.bg, borderRadius: 12, padding: 12, color: colors.text, fontSize: 16 },
  error: { color: '#C0392B', marginTop: 10 },
  btn: { backgroundColor: colors.primary, borderRadius: 14, padding: 14, alignItems: 'center', marginTop: 20 },
  btnTxt: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  link: { marginTop: 20, padding: 8 },
  linkTxt: { color: colors.medium },
  linkBold: { color: colors.primary, fontWeight: 'bold' },
});
