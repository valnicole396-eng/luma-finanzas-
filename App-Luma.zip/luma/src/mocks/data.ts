export const resumen = { saldo: 1240000, ingresos: 2100000, gastos: 860000 };

export const gastosPorCategoria = [
  { categoria: 'Alimentación', monto: 320000 },
  { categoria: 'Transporte', monto: 180000 },
  { categoria: 'Ocio', monto: 150000 },
  { categoria: 'Estudios', monto: 120000 },
  { categoria: 'Otros', monto: 90000 },
];
